"""
CLI handlers for AgentMap using the new service architecture.
"""

from agentmap.core.cli.main_cli import main_cli

__all__ = [
    "main_cli"
]
